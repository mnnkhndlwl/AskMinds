const express = require('express');
const mongoose = require('mongoose')
const bodyParser = require('body-parser');
const cors = require('cors');
const bcrypt = require('bcrypt')
const http = require('http');
const {Server} = require('socket.io');

const app = express();


app.use(cors());

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "http://localhost:5173",
    methods: "GET,HEAD,PUT,PATCH,POST,DELETE",
    credentials: true,
  },
});

const port = 3000;
const Doubt = require('./models/doubts')
const TeachSign = require('./models/signIn')
const StudentSign = require('./models/signStud');
const { log } = require('console');
const db = "mongodb+srv://anupsree:anupsree@cluster0.c5yxeoy.mongodb.net/?retryWrites=true&w=majority"



app.use(bodyParser.json());

// schema for storing chat messages
const chatSchema = new mongoose.Schema({
  senderId: { type: String, required: true },
  recipientId: { type: String, required: true },
  message: { type: String, required: true },
  timestamp: { type: Date, default: Date.now },
});

const Chat = mongoose.model('Chat', chatSchema);


// {socket connection}
io.on('connection', (socket) => {
  console.log(`User connected: ${socket.id}`);
  // socket.on('teachid',({teacherId})=>{
  //   console.log(teacherId);
  // })
  
  socket.on('startChatting', async ({ teacherId, studId }) => {
    console.log(`Teacher ${teacherId} wants to start chatting with Student ${studId}`);
    socket.join(studId);
    socket.to(studId).emit('teachid', { teacherId });
    // Notify the student to start chatting
    socket.to(studId).emit('teacherConnected', { teacherId });
    console.log("notified successfully");
  });

  socket.on('chatMessage', async ({ senderId, recipientId, message }) => {
    console.log(`Message from ${senderId} to ${recipientId}: ${message}`);

    // Save the message to the database
    const chat = new Chat({ senderId, recipientId, message });
    await chat.save();

    // Send the message to the recipient
    io.to(recipientId).emit('chatMessage', { senderId, message });
  });

  socket.on('disconnect', () => {
    console.log(`User disconnected: ${socket.id}`);
  });
});

// {socket ends}
server.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
mongoose.connect(db, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('MongoDB connection error:', err));

// Route for students to post doubts
app.post('/student/post-doubt', async (req, res) => {
  const { studentName, doubtText, studentClass, subject ,studentId  } = req.body;

  if (!studentName || !doubtText || !studentClass || !subject) {
    return res.status(400).json({ error: 'studentName, doubtText, studentClass, and subject are required.' });
  }

  try {
    const newDoubt = new Doubt({
      studentName,
      doubtText,
      studentClass,
      subject,
      studentId
    });

    const savedDoubt = await newDoubt.save();
    const insertedId = newDoubt._id;
    res.status(201).json({savedDoubt,insertedId});
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

//  Route for teachers to get doubts filtered by class and subject
// app.get('/teacher/get-doubts', async (req, res) => {
//   const studentClass = parseInt(req.query.studentClass, 10);
//   const subject = req.query.subject;

//   if (isNaN(studentClass) || !subject) {
//     return res.status(400).json({ error: 'studentClass (as integer) and subject are required query parameters.' });
//   }

//   try {
//     const filteredDoubts = await Doubt.find({ studentClass, subject });
//     res.status(200).json(filteredDoubts);
    
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ error: err.message });
//   }
// });
app.get('/teacher/get-doubts/:id', async (req, res) => {
  const userId = req.params.id;

  try {
    const user = await TeachSign.findById(userId);

    if (!user) {
      return res.status(404).json({ error: 'User not found.' });
    }

    const filteredDoubts = await Doubt.find({
      studentClass: user.classs,
      subject: user.subject
    });

    res.status(200).json(filteredDoubts);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});


// put request to check whether the doubt is accepted or not
app.put('/teacher/accepted', async (req, res) => {
  const {doubtId} = req.body;
  console.log(doubtId);

  try {
    // Check if the doubt is already accepted
    const existingDoubt = await Doubt.findById(doubtId);

    if (!existingDoubt) {
      return res.status(404).json({ message: 'Doubt not found' });
    }

    if (existingDoubt.accepted) {
      return res.status(400).json({ message: 'Doubt already accepted' });
    }

    // Mark the doubt as accepted
    const result = await Doubt.findByIdAndUpdate(doubtId, { accepted: true });

    if (!result) {
      return res.status(404).json({ message: 'Doubt not found' });
    }

    res.status(200).json({ message: 'Doubt accepted successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});

// sign in for teachers
app.post('/teacher/sign', async (req, res) => {
  try {
    const { firstName, lastName, email, password } = req.body;
    const existingUser = await TeachSign.findOne({ email });

    if (existingUser) {
      return res.status(401).json({ message: 'Email already exists' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newLogin = new TeachSign({
      firstName,
      lastName,
      email,
      password: hashedPassword,
    });

    await newLogin.save();
    const insertedId = newLogin._id;
    console.log(insertedId);
    res.status(200).json({ insertedId, message: 'User registered successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error during sign up' });
  }
});

// update class and subject
app.put('/teacher/update', async (req, res) => {
  try {
    const {teacherId, subject: subject, classs: studentClass } = req.body;

    // Find the user by ID
    const user = await TeachSign.findById(teacherId);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Update subject and class
    user.subject = subject 
    user.classs = studentClass 

    // Save the updated user
    await user.save();

    res.status(200).json({ message: 'User information updated successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error updating user information' });
  }
});

app.get('/teacher/information/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const user = await TeachSign.findById(id);

    if (!user) {
      return res.status(404).json({ message: 'user not found' });
    }

    const { classs, subject } = user;
    res.status(200).json({ classs, subject, message: 'successfully retrieved' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Error getting user information' });
  }
});



// login for teachers
app.post('/teacher/login',async(req,res)=>{
  try{
    const {email,password} = req.body;
    const user = await TeachSign.findOne({email:email});
    if(!user){
      console.log("not found");
      return res.status(404).json({ success: false, message: 'User not found' });
    }
    const check = bcrypt.compare(password,user.password);
    if(!check){
      return res.status(401).json({success:false, message:'wrong password'});
    }
    const insertedId = user._id;
    // console.log(insertedId);
    console.log("succesful");
    res.status(200).json({insertedId,message:"logged in succesfully"})
  }
  catch(err){
    return res.status(400).json({message:'error during login'})
  }
})

// sign in for students
app.post('/student/sign', async (req, res) => {
  try {
    const { firstName, lastName, email, password } = req.body;
    const existingUser = await StudentSign.findOne({ email });

    if (existingUser) {
      return res.status(401).json({ message: 'Email already exists' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newLogin = new StudentSign({
      firstName,
      lastName,
      email,
      password: hashedPassword,
    });

    await newLogin.save();
    const insertedId = newLogin._id;
    console.log(insertedId);
    res.status(200).json({ insertedId, message: 'User registered successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error during sign up' });
  }
});


// login for students
app.post('/student/login',async(req,res)=>{
  try{
    const {email,password} = req.body;
    const user = await StudentSign.findOne({email:email});
    if(!user){
      console.log("not found");
      return res.status(404).json({ success: false, message: 'User not found' });
    }
    const check = bcrypt.compare(password,user.password);
    if(!check){
      return res.status(401).json({success:false, message:'wrong password'});
    }
    const insertedId = user._id;
    // console.log(insertedId);
    res.status(200).json({insertedId,message:"logged in succesfully"})
  }
  catch(err){
    return res.status(400).json({message:'error during login'})
  }
})